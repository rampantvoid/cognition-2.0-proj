import UserContext from "./UserContext";
import { useState } from "react";

const UserState = (props) => {
  const userDefault = {};

  const [user, setUser] = useState(userDefault);
  const getUser = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await fetch("http://localhost:5001/api/auth/getUser", {
        method: "POST",
        headers: {
          "Content-Type": " application/json",
        },
        body: JSON.stringify({ token }),
      });

      const json = await response.json();

      setUser(json);
    } catch (e) {
      console.log(e);
    }
  };

  return (
    <UserContext.Provider value={{ user, setUser, getUser }}>
      {props.children}
    </UserContext.Provider>
  );
};

export default UserState;
