import Login from "./components/LoginForm.jsx";
import Register from "./components/Register.jsx";
import Home from "./components/Home.jsx";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import UserState from "./context/UserState.jsx";

function App() {
  return (
    <UserState>
      <Router>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="register" element={<Register />} />
          <Route path="/home" element={<Home />} />
        </Routes>
      </Router>
    </UserState>
  );
}

export default App;
