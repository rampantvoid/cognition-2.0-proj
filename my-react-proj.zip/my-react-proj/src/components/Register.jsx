import { React, useState } from "react";
import "./style.css";
import { Link, useNavigate } from "react-router-dom";

function Register() {
  const [cred, setCred] = useState({
    email: "",
    password: "",
    repwd: "",
  });
  const navigate = useNavigate();
  const { email, password, repwd } = cred;

  const onChange = (e) => {
    setCred((prev) => ({
      ...prev,
      [e.target.id]: e.target.value,
    }));
    // console.log(creds);
  };

  const onSubmit = async (e) => {
    e.preventDefault();

    console.log(cred);

    const data = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(cred),
    };

    try {
      const response = await fetch(
        "http://127.0.0.1:5001/api/auth/register",
        data
      );

      const json = await response.json();

      console.log(json);

      if (json.success) {
        navigate("/home");
      } else {
        console.log(json.err_msg);
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="form-container">
      <div className="form-wrapper">
        <form action="" onSubmit={onSubmit}>
          <div className="input">
            <label htmlFor="email">Email</label>

            <input
              type="email"
              className="email"
              id="email"
              value={email}
              onChange={onChange}
            />
          </div>

          <div className="input">
            <label htmlFor="pwd">Password</label>

            <input
              type="password"
              className="pwd"
              id="password"
              value={password}
              onChange={onChange}
            />
          </div>

          <div className="input">
            <label htmlFor="re-pwd">Re-enter Password</label>

            <input
              type="password"
              className="pwd"
              id="repwd"
              value={repwd}
              onChange={onChange}
            />
          </div>

          <button type="submit">Submit</button>

          <Link to="/">
            <p>Login</p>
          </Link>
        </form>
      </div>
    </div>
  );
}

export default Register;
