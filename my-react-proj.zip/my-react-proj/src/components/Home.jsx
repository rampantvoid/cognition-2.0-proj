import { React, useEffect, useContext } from "react";
import UserContext from "../context/UserContext";
import { Link, useNavigate } from "react-router-dom";
import "./Home.css";

function Home() {
  const context = useContext(UserContext);
  const navigate = useNavigate();

  const { getUser, setUser, user } = context;

  useEffect(() => {
    if (localStorage.getItem("token")) {
      getUser();
    } else {
      navigate("/");
    }
  }, []);

  return (
    <div className="main">
      <h1>Welcome, {user.name}</h1>

      <div className="card-container">
        
        {user.notes?.map((val, key) => {
          return (
            <div key={key} className="card">
              <p>{val}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default Home;
