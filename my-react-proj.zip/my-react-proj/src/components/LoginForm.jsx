import React, { useState } from "react";
import "./style.css";
import { Link, useNavigate } from "react-router-dom";

function LoginForm() {
  let [creds, setCreds] = useState({
    email: "",
    password: "",
  });

  const navigate = useNavigate();

  const onChange = (e) => {
    setCreds((prev) => ({
      ...prev,
      [e.target.id]: e.target.value,
    }));
    // console.log(creds);
  };

  let { email, password } = creds;

  const onSubmit = async (e) => {
    e.preventDefault();

    console.log(creds);

    const data = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(creds),
    };

    try {
      const response = await fetch(
        "http://127.0.0.1:5001/api/auth/login",
        data
      );

      const json = await response.json();
      console.log(json);

      if (json.success) {
        // store jwt token in local storage
        localStorage.setItem("token", json.token);
        navigate("/home");
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="form-container">
      <div className="form-wrapper">
        <form onSubmit={onSubmit}>
          <div className="input">
            <label htmlFor="email">Email</label>

            <input
              onChange={onChange}
              type="email"
              className="email"
              id="email"
              value={email}
            />
          </div>

          <div className="input">
            <label htmlFor="pwd">Password</label>

            <input
              onChange={onChange}
              type="password"
              className="pwd"
              id="password"
              value={password}
            />
          </div>

          <button type="submit">Submit</button>
        </form>

        <Link to={"/register"}>
          <p>Register</p>
        </Link>
      </div>
    </div>
  );
}

export default LoginForm;
