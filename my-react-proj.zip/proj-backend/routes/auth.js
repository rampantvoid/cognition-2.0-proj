const express = require("express");
const User = require("../models/User");
const { json } = require("body-parser");
const router = express.Router();

router.post("/login", async (req, res) => {
  try {
    console.log(req.body);

    const { email, password } = req.body;

    // Checking in database if user is valid or not

    const user = await User.findOne({ email: email, password: password });

    if (user) {
      // if user is valid then sending success: true

      console.log(user.password);

      res.json({ success: true });
    }

    // if user is invalid or does not exist then sending success : false

    res.json({ success: false, err_msg: "incorrect password" });
  } catch (error) {
    console.log(error);
  }
});

router.post("/register", async (req, res) => {
  try {
    console.log(req.body);

    const { email, password } = req.body;

    // checking if the user already exists in the database

    const user = await User.findOne({ email: email });

    if (user) {
      // if yes then send success : false
      res
        .status(400)
        .json({ success: false, err_msg: "User already exist please login" });
    }

    // if not then create a user with provides creds

    await User.create({
      email: email,
      password: password,
    });

    // if successfully created then send success : true

    res.json({ success: true });

    console.log(user);

    res.json({ success: false, err_msg: "incorrect password" });
  } catch (error) {
    console.log(error);
  }
});

module.exports = router;
