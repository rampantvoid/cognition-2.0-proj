const express = require("express");
const User = require("../models/User");
const { json } = require("body-parser");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const router = express.Router();

// ADD A JWT SECRETE
const JWT_KEY = "mykey";

router.post("/login", async (req, res) => {
  try {
    console.log(req.body);

    const { email, password } = req.body;

    // Checking in database if user is valid or not

    const user = await User.findOne({ email: email });

    // comparing password
    // await bcrypt.compare(pass,user.pass)

    if (!user) {
      return res.json({ success: false, err_msg: "Invalid creds" });
    }

    // if user is valid then sending success: true

    // create object to embed in JWT token
    // { user:{ id : user.id, },}

    // create JWT
    // jwt.sign(data,JWT SECRETE)

    const comparePass = await bcrypt.compare(password, user.password);

    const data = {
      user: {
        id: user.id,
      },
    };

    const token = jwt.sign(data, JWT_KEY, { expiresIn: 10000000 });

    if (comparePass) {
      res.json({ success: true, token: token });
    }

    // if user is invalid or does not exist then sending success : false
  } catch (error) {
    console.log(error);
  }
});

router.post("/register", async (req, res) => {
  try {
    console.log(req.body);

    const { email, password } = req.body;

    // checking if the user already exists in the database

    let user = await User.findOne({ email: email });

    if (user) {
      // if yes then send success : false
      res
        .status(400)
        .json({ success: false, err_msg: "User already exist please login" });
    }

    // hashing the password

    // await bcrypt.genSalt()
    // await bcrypt.hash(pass,salt)

    const salt = await bcrypt.genSalt(10);
    const secPass = await bcrypt.hash(password, salt);

    // if not then create a user with provides creds

    user = await User.create({
      email: email,
      password: secPass,
    });

    // if successfully created then send success : true

    const data = {
      user: {
        id: user.id,
      },
    };

    const token = jwt.sign(data, JWT_KEY, { expiresIn: 9999 });

    res.json({ success: true, token: token });

    console.log(user);

    res.json({ success: false, err_msg: "incorrect password" });
  } catch (error) {
    console.log(error);
  }
});

router.post("/verify", (req, res) => {
  // verify jwt token
  // jwt.verify(token,secrete,(err,data))

  console.log(req.body);

  const { token } = req.body;

  const isValid = jwt.verify(token, JWT_KEY, async (err, data) => {
    if (err) {
      console.log(err);
    }
    console.log(data);

    const user = await User.findById(data.user.id);

    console.log(user);
  });
});

router.post("/getUser", async (req, res) => {
  console.log(req.body);

  const { token } = req.body;

  let userID;

  const isValid = jwt.verify(token, JWT_KEY, (err, data) => {
    if (err) {
      return console.log(err);
    }
    console.log(data);

    userID = data.user.id;
  });

  const user = await User.findById(userID).select("-password");

  console.log(user);

  res.json(user);
});

module.exports = router;
