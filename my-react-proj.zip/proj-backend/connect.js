const db = require("mongoose");

const connect = async () => {
  try {
    const response = await db.connect(
      "mongodb+srv://priyanshubutola:test1234@cluster0.utffjmv.mongodb.net/?retryWrites=true&w=majority"
    );
    console.log("Connection OK");
  } catch (err) {
    console.log(err);
  }
};

module.exports = connect;
