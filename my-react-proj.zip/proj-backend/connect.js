const db = require("mongoose");

const connect = async () => {
  try {
    const response = await db.connect(""); // add your connection string here
    console.log("Connection OK");
  } catch (err) {
    console.log(err);
  }
};

module.exports = connect;
