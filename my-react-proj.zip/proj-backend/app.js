const express = require("express");
const DB = require("./connect");
const cors = require("cors");

const app = express();

DB();

app.use(express.json());

app.use(
  cors({
    origin: "*",
  })
);

app.use("/api/auth", require("./routes/auth"));

app.listen(5001, () => {
  try {
    console.log("server is listening on PORT 5001");
  } catch (e) {
    console.log(e);
  }
});
